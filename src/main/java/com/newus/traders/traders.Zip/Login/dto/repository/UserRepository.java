package com.newus.traders.Login.dto.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.newus.traders.Login.User;

public interface UserRepository extends JpaRepository<User, Long> {
    boolean existsByEmail(String email);
    boolean existsByNickname(String nickname);
    Optional<User> findByeEmail(String email);
}
