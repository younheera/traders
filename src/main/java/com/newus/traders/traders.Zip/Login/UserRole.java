package com.newus.traders.Login;

public enum UserRole {
    USER, ADMIN;
}
