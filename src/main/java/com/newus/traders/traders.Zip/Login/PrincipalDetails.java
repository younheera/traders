package com.newus.traders.Login;

public class PrincipalDetails {
    
}
