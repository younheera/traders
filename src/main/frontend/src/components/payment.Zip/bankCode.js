const bankCode = [
    {
      value: '002',
      label: 'KDB 산업',
    },
    {
      value: '003',
      label: 'IBK 기업',
    },
    {
      value: '004',
      label: 'KB 국민',
    },
    {
      value: '007',
      label: '수협',
    },
    {
        value: '011',
        label: 'NH 농협',
      },
    {
        value: '020',
        label: '우리',
    },
    {
        value: '023',
        label: 'sc제일',
    },
    {
        value: '027',
        label: '한국씨티',
    },
    {
        value: '031',
        label: '대구',
    },
    {
        value: '032',
        label: '부산',
    },
    {
        value: '034',
        label: '광주',
    },
    {
        value: '035',
        label: '제주',
    },
    {
        value: '037',
        label: '전북',
    },
    {
        value: '039',
        label: '경남',
    },
    {
        value: '081',
        label: '하나',
    },
    {
        value: '088',
        label: '신한',
    },
    {
        value: '089',
        label: '케이',
    },
    {
        value: '090',
        label: '카카오',
    },
    {
        value: '092',
        label: '토스',
    },

  ];

  export default bankCode;