/**
 * @author ahrayi
 * @create date 2023-10-17 10:13:15
 * @modify date 2023-10-17 11:29:54
 * @desc 임시페이지
 */

import React from 'react';

const AccountRegister4 = () => {
    return (
        <div>
            계좌등록완료
        </div>
   );
};

export default AccountRegister4;